console.log('global');


